Role Name
=========

Single_role

Requirements
------------

Ansible-galaxy collection

Example Playbook
----------------

Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

    - hosts: localhost
      roles:
         - my_own_namespace.yandex_cloud_elk.single_role

License
-------

MIT

Author Information
------------------

amaksimov
